import java.awt.*;
import javax.swing.*;

public class Board
{
    private JButton button1; private JButton button4; private JButton button7;
    private JButton button2; private JButton button5; private JButton button8;
    private JButton button3; private JButton button6; private JButton button9;
    
    public Board(JButton button1, JButton button2, JButton button3, JButton button4, JButton button5, JButton button6, JButton button7, JButton button8, JButton button9)
    {
        this.button1 = button1; this.button4 = button4; this.button7 = button7;
        this.button2 = button2; this.button5 = button5; this.button8 = button8;
        this.button3 = button3; this.button6 = button6; this.button9 = button9;
    }
    
    public void resetBoard()
    {
        button1.setEnabled(true); button4.setEnabled(true); button7.setEnabled(true);
        button2.setEnabled(true); button5.setEnabled(true); button8.setEnabled(true);
        button3.setEnabled(true); button6.setEnabled(true); button9.setEnabled(true);
        
        button1.setBackground(Color.white); button4.setBackground(Color.white); button7.setBackground(Color.white);
        button2.setBackground(Color.white); button5.setBackground(Color.white); button8.setBackground(Color.white);
        button3.setBackground(Color.white); button6.setBackground(Color.white); button9.setBackground(Color.white);
        
        button1.setText("-"); button4.setText("-"); button7.setText("-");
        button2.setText("-"); button5.setText("-"); button8.setText("-");
        button3.setText("-"); button6.setText("-"); button9.setText("-");
        
        button1.setIcon(null); button4.setIcon(null); button7.setIcon(null);
        button2.setIcon(null); button5.setIcon(null); button8.setIcon(null);
        button3.setIcon(null); button6.setIcon(null); button9.setIcon(null);
    }
}