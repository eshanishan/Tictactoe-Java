import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Viewer
{
    public static void main(String[] args)
    {
        String player1Name = "";
        String player1Symbol = "";
        String player2Name = "";
        String player2Symbol = "";
        
        do // Makes sure the players don't have the same symbol because checking if they win is based off their symbol
        {
            player1Name = JOptionPane.showInputDialog("Player 1 Name: ");
            player1Symbol = JOptionPane.showInputDialog("Player 1 Symbol: ");
            player2Name = JOptionPane.showInputDialog("Player 2 Name: ");
            player2Symbol = JOptionPane.showInputDialog("Player 2 Symbol: ");
        }
        while(player1Symbol.equals(player2Symbol));
        
        Player player1 = new Player(player1Name, player1Symbol);
        Player player2 = new Player(player2Name, player2Symbol);
        
        JFrame frame = new JFrame(player1.getName() + "(" + player1.getSymbol() + ") Wins: " + player1.getWins() + ", " + player2.getName() + "(" + player2.getSymbol() + ") Wins: " + player2.getWins());
        JLabel buttons = new JLabel();
        JPanel resetPanel = new JPanel(); // chapter 20 (20.1) in book
        JButton resetButton = new JButton();
        resetPanel.setLayout(new BorderLayout());
        
        resetPanel.add(resetButton, BorderLayout.NORTH);
        
        GridLayout grid = new GridLayout(3,3);
        frame.setLayout(grid);
        
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600,600);
        frame.setVisible(true);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        
        JButton button1 = new JButton("-"); button1.setFont(new Font("Arial", Font.PLAIN, 50)); button1.setBackground(Color.white);
        JButton button2 = new JButton("-"); button2.setFont(new Font("Arial", Font.PLAIN, 50)); button2.setBackground(Color.white);
        JButton button3 = new JButton("-"); button3.setFont(new Font("Arial", Font.PLAIN, 50)); button3.setBackground(Color.white);
        JButton button4 = new JButton("-"); button4.setFont(new Font("Arial", Font.PLAIN, 50)); button4.setBackground(Color.white);
        JButton button5 = new JButton("-"); button5.setFont(new Font("Arial", Font.PLAIN, 50)); button5.setBackground(Color.white);
        JButton button6 = new JButton("-"); button6.setFont(new Font("Arial", Font.PLAIN, 50)); button6.setBackground(Color.white);
        JButton button7 = new JButton("-"); button7.setFont(new Font("Arial", Font.PLAIN, 50)); button7.setBackground(Color.white);
        JButton button8 = new JButton("-"); button8.setFont(new Font("Arial", Font.PLAIN, 50)); button8.setBackground(Color.white);
        JButton button9 = new JButton("-"); button9.setFont(new Font("Arial", Font.PLAIN, 50)); button9.setBackground(Color.white);
        
        Rules checkWin = new Rules(player1, player2, button1, button2, button3, button4, button5, button6, button7, button8, button9);
        Board board = new Board(button1, button2, button3, button4, button5, button6, button7, button8, button9);
        
        class ClickListener implements ActionListener
        {
            private int count = 0;
            private Player player1;
            private Player player2;
            private Rules checkWin;
            private JFrame frame;
            private Board board;
            
            public ClickListener(Rules checkWin, Board board, Player player1, Player player2, JFrame frame)
            {
                this.checkWin = checkWin;
                this.board = board;
                this.player1 = player1;
                this.player2 = player2;
                this.frame = frame;
            }
            
            public void actionPerformed(ActionEvent event)
            {
                JButton button = (JButton) event.getSource();
                button.setEnabled(false);
                
                ImageIcon teele = new ImageIcon("teele.jpg");

                if (count % 2 == 0) 
                {
                    button.setText(player1.getSymbol());
                    if ( player1.getName().equalsIgnoreCase("teele") ) {button.setIcon(teele);}   
                }
                else 
                {
                    button.setText(player2.getSymbol());
                    if ( player2.getName().equalsIgnoreCase("teele") ) {button.setIcon(teele);}
                }
                
                count++;
                
                if ( checkWin.checkP1Rows() || checkWin.checkP1Columns() || checkWin.checkP1Diagonals())
                {
                    player1.addWin(1);    
                    count = 0;
                    if (JOptionPane.showConfirmDialog(null, "Would you like to play again?", player1.getName() + "(" + player1.getSymbol() + ") WINS!", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
                    {
                        board.resetBoard();
                    }
                    else {System.exit(0);}
                }
                
                if ( checkWin.checkP2Rows() || checkWin.checkP2Columns() || checkWin.checkP2Diagonals())
                {
                    player2.addWin(1);
                    count = 0;
                    if (JOptionPane.showConfirmDialog(null, "Would you like to play again?", player2.getName() + "(" + player2.getSymbol() + ") WINS!", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
                    {
                        board.resetBoard();
                    }
                    else {System.exit(0);}
                }
                
                if ( checkWin.checkTie())
                {
                    count = 0;
                    if (JOptionPane.showConfirmDialog(null, "Would you like to play again?" , "It Is A TIE! No One Wins!", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
                    {
                        board.resetBoard();
                    }
                    else {System.exit(0);}
                }
                
                frame.setTitle(player1.getName() + "(" + player1.getSymbol() + ") Wins: " + player1.getWins() + ", " + player2.getName() + "(" + player2.getSymbol() + ") Wins: " + player2.getWins());
            }
        }
        
        ActionListener listener = new ClickListener(checkWin, board, player1, player2, frame);
        
        frame.add(button1); button1.addActionListener(listener);
        frame.add(button2); button2.addActionListener(listener);
        frame.add(button3); button3.addActionListener(listener);
        frame.add(button4); button4.addActionListener(listener);
        frame.add(button5); button5.addActionListener(listener);
        frame.add(button6); button6.addActionListener(listener);
        frame.add(button7); button7.addActionListener(listener);
        frame.add(button8); button8.addActionListener(listener);
        frame.add(button9); button9.addActionListener(listener);
    }
}