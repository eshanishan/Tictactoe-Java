import javax.swing.*;
import java.awt.*;

public class Rules
{
    private Player player1;
    private Player player2;
    
    private JButton button1; private JButton button4; private JButton button7;
    private JButton button2; private JButton button5; private JButton button8;
    private JButton button3; private JButton button6; private JButton button9;
    
    public Rules(Player player1, Player player2, JButton button1, JButton button2, JButton button3, JButton button4, JButton button5, JButton button6, JButton button7, JButton button8, JButton button9)
    {
        this.player1 = player1;
        this.player2 = player2;
        
        this.button1 = button1; this.button4 = button4; this.button7 = button7;
        this.button2 = button2; this.button5 = button5; this.button8 = button8;
        this.button3 = button3; this.button6 = button6; this.button9 = button9;
        
    }

    public boolean checkP1Rows()
    {
        //Row 1 
        if ( button1.getText().equals(player1.getSymbol()) && button2.getText().equals(player1.getSymbol()) && button3.getText().equals(player1.getSymbol()))
        {
            button1.setBackground(Color.green);
            button2.setBackground(Color.green);
            button3.setBackground(Color.green);
            
            button4.setEnabled(false); button5.setEnabled(false); button6.setEnabled(false);
            button7.setEnabled(false); button8.setEnabled(false); button9.setEnabled(false);
            
            return true;
        }
        //Row 2 
        if ( button4.getText().equals(player1.getSymbol()) && button5.getText().equals(player1.getSymbol()) && button6.getText().equals(player1.getSymbol()))
        {
            button4.setBackground(Color.green);
            button5.setBackground(Color.green);
            button6.setBackground(Color.green);
            
            button1.setEnabled(false); button2.setEnabled(false); button3.setEnabled(false);
            button7.setEnabled(false); button8.setEnabled(false); button9.setEnabled(false);
            
            return true;
        }
        //Row 3
        if ( button7.getText().equals(player1.getSymbol()) && button8.getText().equals(player1.getSymbol()) && button9.getText().equals(player1.getSymbol()))
        {
            button7.setBackground(Color.green);
            button8.setBackground(Color.green);
            button9.setBackground(Color.green);
            
            button1.setEnabled(false); button2.setEnabled(false); button3.setEnabled(false);
            button4.setEnabled(false); button5.setEnabled(false); button6.setEnabled(false);
            
            return true;
        }
        
        return false;
    }
    
    public boolean checkP2Rows()
    {
        //Row 1
        if ( button1.getText().equals(player2.getSymbol()) && button2.getText().equals(player2.getSymbol()) && button3.getText().equals(player2.getSymbol()))
        {
            button1.setBackground(Color.green);
            button2.setBackground(Color.green);
            button3.setBackground(Color.green);
            
            button4.setEnabled(false); button5.setEnabled(false); button6.setEnabled(false);
            button7.setEnabled(false); button8.setEnabled(false); button9.setEnabled(false);
            
            return true;
        }
        //Row 2
        if ( button4.getText().equals(player2.getSymbol()) && button5.getText().equals(player2.getSymbol()) && button6.getText().equals(player2.getSymbol()))
        {
            button4.setBackground(Color.green);
            button5.setBackground(Color.green);
            button6.setBackground(Color.green);
            
            button1.setEnabled(false); button2.setEnabled(false); button3.setEnabled(false);
            button7.setEnabled(false); button8.setEnabled(false); button9.setEnabled(false);
            
            return true;
        }
        //Row 3
        if ( button7.getText().equals(player2.getSymbol()) && button8.getText().equals(player2.getSymbol()) && button9.getText().equals(player2.getSymbol()))
        {
            button7.setBackground(Color.green);
            button8.setBackground(Color.green);
            button9.setBackground(Color.green);
            
            button1.setEnabled(false); button2.setEnabled(false); button3.setEnabled(false);
            button4.setEnabled(false); button5.setEnabled(false); button6.setEnabled(false);
            
            return true;
        }
        
        return false;
    }
    
    public boolean checkP1Columns()
    {
        //Column 1 
        if ( button1.getText().equals(player1.getSymbol()) && button4.getText().equals(player1.getSymbol()) && button7.getText().equals(player1.getSymbol()))
        {
            button1.setBackground(Color.green);
            button4.setBackground(Color.green);
            button7.setBackground(Color.green);
            
            button2.setEnabled(false); button5.setEnabled(false); button8.setEnabled(false);
            button3.setEnabled(false); button6.setEnabled(false); button9.setEnabled(false);
            
            return true;
        }
        //Column 2 
        if ( button2.getText().equals(player1.getSymbol()) && button5.getText().equals(player1.getSymbol()) && button8.getText().equals(player1.getSymbol()))
        {
            button2.setBackground(Color.green);
            button5.setBackground(Color.green);
            button8.setBackground(Color.green);
            
            button1.setEnabled(false); button4.setEnabled(false); button7.setEnabled(false);
            button3.setEnabled(false); button6.setEnabled(false); button9.setEnabled(false);
            
            return true;
        }
        //Column 3
        if ( button3.getText().equals(player1.getSymbol()) && button6.getText().equals(player1.getSymbol()) && button9.getText().equals(player1.getSymbol()))
        {
            button3.setBackground(Color.green);
            button6.setBackground(Color.green);
            button9.setBackground(Color.green);
            
            button1.setEnabled(false); button4.setEnabled(false); button7.setEnabled(false);
            button2.setEnabled(false); button5.setEnabled(false); button8.setEnabled(false);
            
            return true;
        }
        
        return false;
    }
    
    public boolean checkP2Columns()
    {
        //Column 1 
        if ( button1.getText().equals(player2.getSymbol()) && button4.getText().equals(player2.getSymbol()) && button7.getText().equals(player2.getSymbol()))
        {
            button1.setBackground(Color.green);
            button4.setBackground(Color.green);
            button7.setBackground(Color.green);
            
            button2.setEnabled(false); button5.setEnabled(false); button8.setEnabled(false);
            button3.setEnabled(false); button6.setEnabled(false); button9.setEnabled(false);
            
            return true;
        }
        //Column 2 
        if ( button2.getText().equals(player2.getSymbol()) && button5.getText().equals(player2.getSymbol()) && button8.getText().equals(player2.getSymbol()))
        {
            button2.setBackground(Color.green);
            button5.setBackground(Color.green);
            button8.setBackground(Color.green);
            
            button1.setEnabled(false); button4.setEnabled(false); button7.setEnabled(false);
            button3.setEnabled(false); button6.setEnabled(false); button9.setEnabled(false);
            
            return true;
        }
        //Column 3
        if ( button3.getText().equals(player2.getSymbol()) && button6.getText().equals(player2.getSymbol()) && button9.getText().equals(player2.getSymbol()))
        {
            button3.setBackground(Color.green);
            button6.setBackground(Color.green);
            button9.setBackground(Color.green);
            
            button1.setEnabled(false); button4.setEnabled(false); button7.setEnabled(false);
            button2.setEnabled(false); button5.setEnabled(false); button8.setEnabled(false);
            
            return true;
        }
        
        return false;
    }
    
    public boolean checkP1Diagonals()
    {
        //Diagonal 1 
        if ( button1.getText().equals(player1.getSymbol()) && button5.getText().equals(player1.getSymbol()) && button9.getText().equals(player1.getSymbol()))
        {
            button1.setBackground(Color.green);
            button5.setBackground(Color.green);
            button9.setBackground(Color.green);
            
            button2.setEnabled(false); button3.setEnabled(false); button4.setEnabled(false);
            button6.setEnabled(false); button7.setEnabled(false); button8.setEnabled(false);
            
            return true;
        }
        //Diagonal 2 
        if ( button3.getText().equals(player1.getSymbol()) && button5.getText().equals(player1.getSymbol()) && button7.getText().equals(player1.getSymbol()))
        {
            button3.setBackground(Color.green);
            button5.setBackground(Color.green);
            button7.setBackground(Color.green);
            
            button2.setEnabled(false); button1.setEnabled(false); button4.setEnabled(false);
            button6.setEnabled(false); button9.setEnabled(false); button8.setEnabled(false);
            
            return true;
        }
        
        return false; 
    }
    
    public boolean checkP2Diagonals()
    {
        //Diagonal 1
        if ( button1.getText().equals(player2.getSymbol()) && button5.getText().equals(player2.getSymbol()) && button9.getText().equals(player2.getSymbol()))
        {
            button1.setBackground(Color.green);
            button5.setBackground(Color.green);
            button9.setBackground(Color.green);
            
            button2.setEnabled(false); button3.setEnabled(false); button4.setEnabled(false);
            button6.setEnabled(false); button7.setEnabled(false); button8.setEnabled(false);
            
            return true;
        }
        //Diagonal 2 
        if ( button3.getText().equals(player2.getSymbol()) && button5.getText().equals(player2.getSymbol()) && button7.getText().equals(player2.getSymbol()))
        {
            button3.setBackground(Color.green);
            button5.setBackground(Color.green);
            button7.setBackground(Color.green);
            
            button2.setEnabled(false); button1.setEnabled(false); button4.setEnabled(false);
            button6.setEnabled(false); button9.setEnabled(false); button8.setEnabled(false);
            
            return true;
        }
        
        return false; 
    }
    
    public boolean checkTie()
    {
        if (!(button1.getText().equals("-")) &&
            !(button2.getText().equals("-")) && 
            !(button3.getText().equals("-")) && 
            !(button4.getText().equals("-")) && 
            !(button5.getText().equals("-")) && 
            !(button6.getText().equals("-")) && 
            !(button7.getText().equals("-")) && 
            !(button8.getText().equals("-")) && 
            !(button9.getText().equals("-")) )
            {
                return true;
            }
        return false;
    }
}