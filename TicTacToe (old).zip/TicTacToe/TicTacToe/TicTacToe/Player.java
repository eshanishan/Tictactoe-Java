public class Player
{
    private String name;
    private String symbol;
    private int totalWins;
    
    public Player(String playerName, String playerSymbol)
    {
        name = playerName;
        symbol = playerSymbol;
        totalWins = 0;
    }
    
    public String getName()
    {
        return name;
    }
    
    public String getSymbol()
    {
        return symbol;
    }
    
    public int getWins()
    {
        return totalWins;
    }
    
    public void addWin(int amount)
    {
        totalWins += amount;
    }
}